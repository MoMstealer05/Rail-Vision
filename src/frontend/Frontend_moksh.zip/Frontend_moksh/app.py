import cv2
from flask import Flask, render_template, Response, request, jsonify
from PIL import Image, ImageDraw, ImageFilter
import io
import time
import base64
import numpy as np
import os
import tempfile

app = Flask(__name__)

# --- SIMULATION LOGIC ---
def generate_fake_frame(frame_count, cam_id=0):
    width, height = 640, 360
    img = Image.new("RGB", (width, height), "#0f172a")
    draw = ImageDraw.Draw(img)
    
    speed = 18
    wagon_x = (frame_count * speed) % (width + 500) - 300
    cam_labels = ["CAM-01 (SIDE VIEW)", "CAM-02 (TOP VIEW)", "CAM-03 (UNDERBODY)"]
    current_label = cam_labels[int(cam_id)]
    
    # Draw Wagon
    draw.rectangle([wagon_x, 50, wagon_x + 350, 320], fill="#475569", outline="#1e293b", width=3)
    draw.text((20, 20), current_label, fill="#fca5a5")
    draw.text((wagon_x + 20, 280), f"UIC: {10420 + (frame_count // 60)}-7", fill="#94a3b8")

    # Simulate Defect
    cycle = frame_count % 120
    has_defect = 40 < cycle < 55
    processed = img.copy()
    p_draw = ImageDraw.Draw(processed)

    if has_defect:
        defect_x = wagon_x + 200
        defect_y = 180
        p_draw.rectangle([defect_x - 20, defect_y - 20, defect_x + 30, defect_y + 40], outline="#00ff00", width=3)
        p_draw.text((defect_x - 20, defect_y - 40), f"⚠ CRACK 99.8%", fill="#00ff00")
        draw.line([defect_x, defect_y, defect_x + 10, defect_y + 25], fill="#ef4444", width=4)

    raw = img.copy()
    raw = Image.eval(raw, lambda x: x * 0.6)
    raw = raw.filter(ImageFilter.GaussianBlur(radius=1.5))
    
    return raw, processed

def image_to_bytes(img):
    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=85)
    return buf.getvalue()

def generate_stream(mode='raw', cam_id=0):
    frame_idx = 0
    while True:
        raw, processed = generate_fake_frame(frame_idx, cam_id)
        target = raw if mode == 'raw' else processed
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + image_to_bytes(target) + b'\r\n')
        frame_idx += 1
        time.sleep(0.04)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed_raw/<int:cam_id>')
def video_feed_raw(cam_id):
    return Response(generate_stream('raw', cam_id), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/video_feed_ai/<int:cam_id>')
def video_feed_ai(cam_id):
    return Response(generate_stream('ai', cam_id), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['image']
    if not file: return jsonify({'error': 'No file'})

    filename = file.filename.lower()
    is_video = filename.endswith('.mp4') or filename.endswith('.avi')
    raw_pil = None

    if is_video:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.mp4') as tfile:
            file.save(tfile.name)
            cap = cv2.VideoCapture(tfile.name)
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            cap.set(cv2.CAP_PROP_POS_FRAMES, total_frames // 2)
            ret, frame = cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                raw_pil = Image.fromarray(frame)
            cap.release()
            os.unlink(tfile.name)
    else:
        img_bytes = file.read()
        raw_pil = Image.open(io.BytesIO(img_bytes)).convert("RGB")

    if raw_pil is None: return jsonify({'error': 'Error'})

    raw_pil = raw_pil.resize((640, 360))
    processed = raw_pil.copy()
    draw = ImageDraw.Draw(processed)
    w, h = processed.size
    draw.rectangle([w//2 - 60, h//2 - 60, w//2 + 60, h//2 + 60], outline="#00ff00", width=4)
    draw.text((w//2 - 60, h//2 - 80), "⚠ Defect Detected (99.8%)", fill="#00ff00")

    def to_b64(img):
        buf = io.BytesIO()
        img.save(buf, format='JPEG')
        return base64.b64encode(buf.getvalue()).decode('utf-8')

    return jsonify({
        'processed_image': f"data:image/jpeg;base64,{to_b64(processed)}"
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)