import cv2
import numpy as np
from flask import Flask, render_template, Response, request, jsonify, send_file
from PIL import Image, ImageDraw, ImageFilter
import io, time, base64, os, random, zipfile, csv, uuid, shutil

app = Flask(__name__)

# --- CONFIGURATION ---
# Folder to store live captures (images + mp4s)
CAPTURE_FOLDER = 'static/live_captures'
if os.path.exists(CAPTURE_FOLDER):
    shutil.rmtree(CAPTURE_FOLDER) # Clean up previous session
os.makedirs(CAPTURE_FOLDER)

# Session Stores
session_data = {}  # For the manual upload section
live_defect_log = [] # For the automated live feed log
last_logged_cycle = -1 # To prevent duplicate logging of the same wagon

# --- HELPER: SAVE EVIDENCE (JPG + MP4) ---
def save_evidence(image_pil, defect_type, uic_num, cam_id, camera_label):
    """Saves a JPG and a short MP4 clip of the defect using OpenCV."""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    base_name = f"{timestamp}_{uic_num}_{defect_type.replace(' ', '_')}"
    
    # 1. Save Image
    img_filename = f"{base_name}.jpg"
    img_path = os.path.join(CAPTURE_FOLDER, img_filename)
    image_pil.save(img_path)

    # 2. Save MP4 Clip (Simulating a 1-second clip)
    vid_filename = f"{base_name}.mp4"
    vid_path = os.path.join(CAPTURE_FOLDER, vid_filename)
    
    # Convert PIL to OpenCV format (RGB -> BGR)
    open_cv_image = cv2.cvtColor(np.array(image_pil), cv2.COLOR_RGB2BGR)
    height, width, _ = open_cv_image.shape
    
    # Create VideoWriter
    fourcc = cv2.VideoWriter_fourcc(*'mp4v') 
    out = cv2.VideoWriter(vid_path, fourcc, 10.0, (width, height))
    
    # Write 10 frames to simulate a short clip
    for _ in range(10):
        out.write(open_cv_image)
    out.release()

    # Log to global list
    live_defect_log.append({
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "uic_number": uic_number,
        "camera_source": camera_label,
        "defect_type": defect_type,
        "confidence": f"{random.randint(88, 99)}%",
        "image_file": img_filename,
        "video_file": vid_filename
    })

# --- SIMULATION LOGIC ---
def generate_fake_frame(frame_count, cam_id=0):
    global last_logged_cycle, uic_number

    width, height = 640, 360
    img = Image.new("RGB", (width, height), "#0f172a")
    draw = ImageDraw.Draw(img)
    
    speed = 18
    wagon_x = (frame_count * speed) % (width + 500) - 300
    cam_labels = ["CAM-01 (SIDE)", "CAM-02 (TOP)", "CAM-03 (UNDERBODY)"]
    current_label = cam_labels[int(cam_id) % 3]
    
    # Determine Wagon ID
    uic_number = f"{10420 + (frame_count // 200)}-7"
    
    draw.rectangle([wagon_x, 50, wagon_x + 350, 320], fill="#475569", outline="#1e293b", width=3)
    draw.text((20, 20), current_label, fill="#fca5a5")
    draw.text((wagon_x + 20, 280), f"UIC: {uic_number}", fill="#94a3b8")

    # Defect Logic
    cycle_length = 200 
    cycle = frame_count % cycle_length
    has_defect = 50 < cycle < 60
    
    defect_types = ["Dent", "Crack", "Rust", "Bolt"]
    defect_type = defect_types[(frame_count // 100) % 4]
    
    processed = img.copy()
    p_draw = ImageDraw.Draw(processed)

    if has_defect:
        defect_x = wagon_x + 200
        defect_y = 180
        color = "#ef4444" if defect_type in ["Crack", "Rust"] else "#eab308"
        p_draw.rectangle([defect_x - 30, defect_y - 30, defect_x + 30, defect_y + 30], outline=color, width=3)
        p_draw.text((defect_x - 30, defect_y - 50), f"⚠ {defect_type.upper()} 98%", fill=color)
        
        # --- AUTOMATIC LOGGING TRIGGER ---
        # Only Cam 0 logs to avoid duplicates, and check if we already logged this cycle
        current_cycle_id = frame_count // cycle_length
        if cam_id == 0 and current_cycle_id != last_logged_cycle:
            last_logged_cycle = current_cycle_id
            save_evidence(processed, defect_type, uic_number, cam_id, current_label)
            print(f"Logged: {defect_type} on {uic_number}")

    raw = img.copy()
    raw = Image.eval(raw, lambda x: x * 0.6)
    raw = raw.filter(ImageFilter.GaussianBlur(radius=1.5))
    return raw, processed

def image_to_bytes(img):
    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=70)
    return buf.getvalue()

def generate_stream(mode='raw', cam_id=0):
    frame_idx = 0
    while True:
        raw, processed = generate_fake_frame(frame_idx, cam_id)
        target = raw if mode == 'raw' else processed
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + image_to_bytes(target) + b'\r\n')
        frame_idx += 1
        time.sleep(0.05) 

# --- ROUTES ---

@app.route('/')
def index():
    session_data.clear()
    return render_template('index.html')

@app.route('/video_feed_raw/<int:cam_id>')
def video_feed_raw(cam_id):
    return Response(generate_stream('raw', cam_id), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/video_feed_ai/<int:cam_id>')
def video_feed_ai(cam_id):
    return Response(generate_stream('ai', cam_id), mimetype='multipart/x-mixed-replace; boundary=frame')

# --- NEW: DOWNLOAD LIVE LOG ZIP ---
@app.route('/download_live_report')
def download_live_report():
    if not live_defect_log:
        return "No defects detected in current session.", 404

    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
        
        # 1. Create CSV
        si = io.StringIO()
        cw = csv.writer(si)
        cw.writerow(['Timestamp', 'UIC Number', 'Camera', 'Defect', 'Confidence', 'Image', 'Video'])
        
        for entry in live_defect_log:
            cw.writerow([
                entry['timestamp'], entry['uic_number'], entry['camera_source'], 
                entry['defect_type'], entry['confidence'], entry['image_file'], entry['video_file']
            ])
            
            # 2. Add Media Files
            try:
                zip_file.write(os.path.join(CAPTURE_FOLDER, entry['image_file']), entry['image_file'])
                zip_file.write(os.path.join(CAPTURE_FOLDER, entry['video_file']), entry['video_file'])
            except FileNotFoundError:
                pass
        
        zip_file.writestr("Live_Session_Report.csv", si.getvalue())

    zip_buffer.seek(0)
    return send_file(zip_buffer, mimetype="application/zip", as_attachment=True, download_name=f"LiveReport_{time.strftime('%H%M')}.zip")

# --- MANUAL UPLOAD ROUTES (UNCHANGED) ---
@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['image']
    if not file: return jsonify({'error': 'No file'})
    
    file_id = str(uuid.uuid4())
    filename = file.filename
    
    img_bytes = file.read()
    raw_pil = Image.open(io.BytesIO(img_bytes)).convert("RGB").resize((640, 360))
    processed = raw_pil.copy()
    draw = ImageDraw.Draw(processed)
    w, h = processed.size
    
    defect_type = random.choice(["Dent", "Crack", "Rust", "Structural"])
    confidence = round(random.uniform(85.0, 99.9), 1)
    
    draw.rectangle([w//2 - 60, h//2 - 60, w//2 + 60, h//2 + 60], outline="#eab308", width=4)
    draw.text((w//2 - 60, h//2 - 80), f"⚠ {defect_type.upper()} ({confidence}%)", fill="#eab308")

    session_data[file_id] = {
        "filename": filename,
        "defect": defect_type,
        "confidence": confidence,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }

    def to_b64(img):
        buf = io.BytesIO()
        img.save(buf, format='JPEG')
        return base64.b64encode(buf.getvalue()).decode('utf-8')

    return jsonify({
        'id': file_id,
        'filename': filename,
        'defect': defect_type,
        'confidence': confidence,
        'processed_image': f"data:image/jpeg;base64,{to_b64(processed)}"
    })

@app.route('/download_csv/<file_id>')
def download_csv(file_id):
    if file_id not in session_data: return "File not found", 404
    data = session_data[file_id]
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['Filename', 'Timestamp', 'Defect Type', 'Confidence Score', 'Status'])
    cw.writerow([data['filename'], data['timestamp'], data['defect'], f"{data['confidence']}%", 'Flagged'])
    output = io.BytesIO()
    output.write(si.getvalue().encode('utf-8'))
    output.seek(0)
    return send_file(output, mimetype="text/csv", as_attachment=True, download_name=f"report_{data['filename']}.csv")

@app.route('/download_all_zip')
def download_all_zip():
    if not session_data: return "No data to export", 404
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
        for f_id, data in session_data.items():
            csv_content = f"Filename,Timestamp,Defect Type,Confidence,Status\n{data['filename']},{data['timestamp']},{data['defect']},{data['confidence']}%,'Flagged'"
            zip_file.writestr(f"report_{data['filename']}.csv", csv_content)
    zip_buffer.seek(0)
    return send_file(zip_buffer, mimetype="application/zip", as_attachment=True, download_name="all_reports.zip")

if __name__ == '__main__':
    app.run(debug=True, port=5000, threaded=True)